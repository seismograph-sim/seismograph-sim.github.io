# TODO — ideas to add next

## Done ✅
- [x] Add a magnitude slider (a bigger quake shakes cities harder and farther).
- [x] Draw the tectonic plate boundaries and start quakes on a real fault line.
- [x] Make small quakes affect fewer cities than big quakes.
- [x] Let the user click the map to choose where the quake starts.
- [x] Glow the fault line that caused the quake.
- [x] Live countdown per city, then make the dot shake when the wave arrives.

## Still to do
- [ ] Show both the fast **P-wave** and the slower **S-wave** as two rings.
- [ ] Add more cities — maybe every capital city in the world.
- [ ] Play a soft "ding" sound each time a wave reaches a city.
- [ ] Show a little popup on each city with its distance in km.
- [ ] Add a "replay" button to watch the last quake again.
- [ ] Use real earthquake data from the USGS instead of random quakes.
- [ ] Make the shaking colours match the real Mercalli intensity scale.
- [ ] Add a dark/light theme toggle.
