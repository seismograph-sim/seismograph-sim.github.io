# 🌏 Seismograph

A tiny pretend earthquake simulator that runs entirely in your web browser.
No server, no installing anything, no "build step" — just open `index.html`
and it works.

Pick a **magnitude** with the slider, then **click anywhere on the map** to
start a quake there — or press **⚡ Trigger a quake** for a random one on a
fault. The **tectonic plate boundary** nearest the quake glows green (that's
where real quakes come from — the orange lines are all the world's faults).

Waves spread out like ripples in a pond. Each city the wave reaches gets a
live **countdown** in the arrivals log ("San Francisco: shaking in 5 s"), and
when the countdown hits zero that city's dot **shakes** and turns "🌋 shaking!"
The dot's colour shows how hard it shakes (red = strong, green = barely felt),
which fades the farther the city is from the quake.

A **small** quake only reaches nearby cities; a **big** one reaches far-away
ones too. Cities outside the "felt zone" don't shake at all. (We only show 16
cities, so the counts mean "of the cities on our map" — there are thousands of
real cities we don't draw.)

## What each file does

- **index.html** — The skeleton of the page. It loads the Leaflet map library
  from the internet, makes a full-window box for the map, and adds the sidebar
  with the title, the status line, the button, and the arrivals log.
- **style.css** — The "paint and decoration." It makes the map fill the screen,
  puts the dark sidebar in the corner, styles the red button, and sets the
  colours and fonts.
- **main.js** — The "brain." It draws the map, places the cities, runs the math
  (Haversine distances and the min-heap priority queue), and animates the
  earthquake waves.
- **README.md** — This file: what the project is and how it works.
- **TODO.md** — A wish-list of ideas to add next.

## Where do the quakes come from?

The Earth's crust is cracked into giant puzzle pieces called **tectonic
plates**. Earthquakes happen along the cracks where the plates push against
each other. The app downloads those crack-lines as map data, draws them in
orange, and starts every quake somewhere along one — just like the real world.
The **magnitude** (how big the quake is) decides how far the shaking can be
felt and how hard it hits each city.

## The two big ideas

### The Haversine formula (how far apart are two cities?)

The Earth is a ball, not a flat piece of paper. So if you want the real
distance between two places, you can't just use a straight ruler — you have to
measure *along the curve* of the planet. The **Haversine formula** does exactly
that. You give it two latitude/longitude points and it gives you the
**great-circle distance** (the shortest path over the round surface), which we
use to figure out how far each city is from the earthquake.

### The min-heap priority queue (what happens next?)

After a quake, every city has a wave **arrival time** (`distance ÷ wave speed`).
We want to handle the cities **in the order the wave reaches them** — nearest
first, farthest last. A **min-heap priority queue** is a data structure that
always hands you the smallest item first. We push every city in with its
arrival time, then pop them out one by one — and they come out perfectly
sorted by "who gets shaken next." It stays fast even with thousands of cities,
which is why real "what happens next?" simulations (and games) use it too.

## Run it on your computer

Just double-click `index.html`, or from a terminal:

```bash
open index.html      # macOS
```

(The map needs an internet connection to download the map tiles and the
Leaflet library.)
